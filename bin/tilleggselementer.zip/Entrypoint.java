import spillelementer.MultiplayerMainframe;

public class Entrypoint {

	public static void main(String[] s) {
		MultiplayerMainframe damspill = new MultiplayerMainframe();
	}

}
