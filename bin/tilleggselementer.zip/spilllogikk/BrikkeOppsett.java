package spilllogikk;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.JOptionPane;

public class BrikkeOppsett{
	
		boolean jegErHvit;
		public int [] brikkeKart;
		public int[][] brikkerSomBlirHoppetOver = new int[64][4];
		public int[][] lovligeHopp = new int[64][4];
		public int sumMineBrikker, sumMotspillerBrikker, motstanderSisteFraTrekk, motstanderSisteTilTrekk; // fra/til trekk er for � lage pil
		public boolean tapt = false;
		public boolean vunnet = false;
		public boolean lovligeHoppFunnet = false;
		public boolean lovligeTrekkFunnet = false;
		
		public ArrayList<Integer> lovligeTrekk = new ArrayList<Integer>();
		public boolean jegVilStartePaNytt;
		public boolean motspillerVilStartePaNytt;
		public ArrayList<Integer> motstanderSinBrikkePos = new ArrayList<Integer>();
		public boolean funnetMotstanderSittSisteTrekk;
		
		public BrikkeOppsett(boolean jegErHvit) {
			nyttBrikkekart();
			lagreMotstanderSinBrikkePos();
			this.jegErHvit = jegErHvit;
		}
				
		public void resetStartPaNytt(){
			tapt = false;
			vunnet = false;
			motspillerVilStartePaNytt = false;
			jegVilStartePaNytt = false;
			brikkeKart[0] = 0;
		}
		
		public void restart(){
			tapt = false;
			vunnet = false;
			lovligeHoppFunnet = false;
			lovligeTrekkFunnet = false;
			jegVilStartePaNytt = false;
			motspillerVilStartePaNytt = false;
			funnetMotstanderSittSisteTrekk = false;
			lovligeTrekk.clear();
			resetLovligeHopp();
			resetStartPaNytt();
			resetBrikkerSomBlirHoppetOver();
		}
		
		public void varSjekk(){
			harJegTapt();
			harJegVunnet();
			if(!tapt && !vunnet){
				sjekkBrikkeStatus();
				sjekkLovligeHopp();
			}
		}
		
		public void setFunnetMotstanderSittSisteTrekk(boolean b) {
			funnetMotstanderSittSisteTrekk = false;
		}
		
		public boolean getFunnetMotstanderSittSisteTrekk(){
			return funnetMotstanderSittSisteTrekk;
		}
		public int getMotstanderSisteTilTrekk(){
			return motstanderSisteTilTrekk;
		}
		
		public int getMotstanderSisteFraTrekk(){
			return motstanderSisteFraTrekk;
		}
		
		public void tellMotspillersBrikker() {
			int sum = 0;
			for(int i = 0; i < brikkeKart.length; i++){
				if(erDetteMotstanderenSinBrikke(i)){
					sum++;
				}
			}
			sumMotspillerBrikker = sum;
		}

		public void tellMineBrikker() {
			int sum = 0;
			for(int i = 0; i < brikkeKart.length; i++){
				if(erDetteMinBrikke(i)){
					sum++;
				}
			}
			sumMineBrikker = sum;
		}

		public boolean skalJegStartePaNytt(){
			return jegVilStartePaNytt && motspillerVilStartePaNytt;
		}
		
		public boolean motspillerVilStartePaNyttOgJegMaSvare(){
			return (motspillerVilStartePaNytt  == true && jegVilStartePaNytt == false);
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		public int getSumMineBrikker(){
			return sumMineBrikker;
		}
		public int getSumMotstanderBrikker(){
			return sumMotspillerBrikker;
		}
		public ArrayList<Integer> getLovligeTrekk() {
			return lovligeTrekk;
		}
		
		public int[] getBrikkeKart(){
			return brikkeKart;
		}
		
		public int[][] getLovligeHopp(){
			return lovligeHopp;
		}
		
		public boolean getTap(){
			return tapt;
		}
		
		public boolean getVunnet(){
			return vunnet;
		}
		
		public boolean getLovligeHoppFunnet() {
			return lovligeHoppFunnet;
		}
		public boolean getLovligeTrekkFunnet() {
			return lovligeTrekkFunnet;
		}
		
		public int[][] getBrikkerSomBlirHoppetOver(){
			return brikkerSomBlirHoppetOver;
		}
		
		public void setBrikkeKart(int[] brikkeKart){
			this.brikkeKart = brikkeKart;
		}

		public void setJegVilStartePaNytt(boolean jegVilStartePaNytt) {
			this.jegVilStartePaNytt = jegVilStartePaNytt;
		}
		
		
		public void nyttBrikkekart() {
			int nyttBrikkeKart[] = new int[64];
			for(int i = 0; i < 64; i++){
					boolean partallRad = (i/8)%2==0;
					boolean partallRute = i%2==0;
					int brikketype = 0;
					if(i>=40 || i<24){
						if((!partallRad && partallRute) || (partallRad && !partallRute)){
							if(i>=40) brikketype = 1;
							if(i<24) brikketype = 3;
						}
					}
					nyttBrikkeKart[i] = brikketype;
				}
			brikkeKart = nyttBrikkeKart;
		}
		
		public void hvittBrikkeKart() {
			int[] nyttBrikkeKart = new int[64];
			for(int i = 0; i < 64; i++){
					brikkeKart[i] = 2;
				}
			brikkeKart = nyttBrikkeKart;
		}
		
		public void svartBrikkeKart() {
			int nyttBrikkeKart[] = new int[64];
			for(int i = 0; i < 64; i++){
					brikkeKart[i] = 4;
				}
			brikkeKart = nyttBrikkeKart;
		}
		
		
		public void nyttRiggedBrikkekart() {
			int[] nyttBrikkeKart1 = {
				0,3,0,0,0,0,0,0,
				0,0,0,0,1,0,0,0,
				0,0,0,3,0,0,0,0,
				1,0,0,0,3,0,0,0,
				0,0,0,0,0,0,0,0,
				0,0,1,0,0,0,0,0,
				0,0,0,3,0,0,0,1,
				0,0,0,0,0,0,0,0,
			};
			int[] nyttBrikkeKart = {
					0,0,0,0,0,0,0,0,
					0,0,0,0,0,0,0,0,
					0,0,0,3,0,0,0,0,
					0,0,0,0,3,0,0,0,
					0,0,0,0,0,0,0,0,
					0,0,0,0,0,0,0,0,
					0,0,0,0,0,0,0,1,
					0,0,0,0,0,0,0,0,
				};
			brikkeKart = nyttBrikkeKart;
		}
		
		public void skrivUtBrikkekart() {
			int teller=0;
			for(int i = 0; i < brikkeKart.length; i++){
				System.out.print(brikkeKart[i]+" ");
				teller++;
				int asd = teller/8;
				if(asd > 0){
					System.out.println();
					teller=0;
				}
			}
			System.out.println();
		}
		
		public void sjekkBrikkeStatus() {
			for(int i = 1; i < brikkeKart.length; i++){
				if((brikkeKart[i] == 1 && i < 8) || (brikkeKart[i] == 3 && i > 55)){
					brikkeKart[i] = brikkeKart[i]+1;
				}
			}
		}
				
		public void finnLovligeTrekkForDenneBrikken(int position) {
			lovligeTrekk.clear();
			lovligeTrekkFunnet = false;
			int brikkeType = brikkeKart[position];
			boolean brikkeKanGaOpp = brikkeKanGaOpp(brikkeType);
			boolean brikkeKanGaNed = brikkeKanGaNed(brikkeType);
			if(trekkNW(position) && brikkeKanGaOpp && feltErTomt(punktNW(position))){

				lovligeTrekk.add(punktNW(position));
				lovligeTrekkFunnet = true;
			}
			if(trekkNE(position) && brikkeKanGaOpp && feltErTomt(punktNE(position))){

				lovligeTrekk.add(punktNE(position));
				lovligeTrekkFunnet = true;
			}
			if(trekkSW(position) && brikkeKanGaNed && feltErTomt(punktSW(position))){

				lovligeTrekk.add(punktSW(position));
				lovligeTrekkFunnet = true;
			}
			if(trekkSE(position) && brikkeKanGaNed && feltErTomt(punktSE(position))){

				lovligeTrekk.add(punktSE(position));
				lovligeTrekkFunnet = true;
			}	
		}
		
		public boolean finnesDetLovligeTrekkForDenneBrikken(int position){
			boolean funnetLovligeTrekk = false;
			int brikkeType = brikkeKart[position];
			boolean brikkeKanGaOpp = brikkeKanGaOpp(brikkeType);
			boolean brikkeKanGaNed = brikkeKanGaNed(brikkeType);
			if(trekkNW(position) && brikkeKanGaOpp && feltErTomt(punktNW(position))){
					funnetLovligeTrekk = true;
			}
			if(trekkNE(position) && brikkeKanGaOpp && feltErTomt(punktNE(position))){
					funnetLovligeTrekk = true;
			}
			if(trekkSW(position) && brikkeKanGaNed && feltErTomt(punktSW(position))){
					funnetLovligeTrekk = true;
			}
			if(trekkSE(position) && brikkeKanGaNed && feltErTomt(punktSE(position))){
					funnetLovligeTrekk = true;
			}
			return funnetLovligeTrekk;
		}
		
		
		public boolean brikkeKanGaOpp(int brikkeType){
			return (brikkeType > 0 && brikkeType !=3);
		}
		
		public boolean brikkeKanGaNed(int brikkeType){
			return (brikkeType > 0 && brikkeType !=1);
		}
		
		public boolean trekkNW(int position){
			int vannrett = position%8-1;
			int loddrett = position/8-1;
			return (loddrett >= 0 && vannrett >= 0 && loddrett < 8 && vannrett < 8);
		}
		
		public boolean trekkNE(int position){
			int vannrett = position%8+1;
			int loddrett = position/8-1;
			return (loddrett >= 0 && vannrett >= 0 && loddrett < 8 && vannrett < 8);
		}
		
		public boolean trekkSW(int position){
			int vannrett = position%8-1;
			int loddrett = position/8+1;
			return (loddrett >= 0 && vannrett >= 0 && loddrett < 8 && vannrett < 8);
		}
		
		public boolean trekkSE(int position){
			int vannrett = position%8+1;
			int loddrett = position/8+1;
			return (loddrett >= 0 && vannrett >= 0 && loddrett < 8 && vannrett < 8);
		}
		
		public boolean hoppNW(int position){
			int vannrett = position%8-2;
			int loddrett = position/8-2;
			return (loddrett >= 0 && vannrett >= 0 && loddrett < 8 && vannrett < 8);
		}
		
		public boolean hoppNE(int position){
			int vannrett = position%8+2;
			int loddrett = position/8-2;
			return (loddrett >= 0 && vannrett >= 0 && loddrett < 8 && vannrett < 8);
		}
		
		public boolean hoppSW(int position){
			int vannrett = position%8-2;
			int loddrett = position/8+2;
			return (loddrett >= 0 && vannrett >= 0 && loddrett < 8 && vannrett < 8);
		}
		
		public boolean hoppSE(int position){
			int vannrett = position%8+2;
			int loddrett = position/8+2;
			return (loddrett >= 0 && vannrett >= 0 && loddrett < 8 && vannrett < 8);
		}
		
		
		
		public int punktNW(int position){
			return (((position/8)-1)*8)+(position%8)-1;
		}
		
		public int punktNE(int position){
			return (((position/8)-1)*8)+(position%8)+1;
		}
		
		public int punktSW(int position){
			return (((position/8)+1)*8)+(position%8)-1;
		}
		
		public int punktSE(int position){
			return (((position/8)+1)*8)+(position%8)+1;
		}
		
		public int hoppPunktNW(int position){
			return (((position/8)-2)*8)+(position%8)-2;
		}
		
		public int hoppPunktNE(int position){
			return (((position/8)-2)*8)+(position%8)+2;
		}
		
		public int hoppPunktSW(int position){
			return (((position/8)+2)*8)+(position%8)-2;
		}
		
		public int hoppPunktSE(int position){
			return (((position/8)+2)*8)+(position%8)+2;
		}

		public boolean feltErTomt(int position){
			return (brikkeKart[position] ==0);
		}
		
		public boolean erDetteMinBrikke(int brikke) {
			if(jegErHvit && (brikkeKart[brikke] == 2 || brikkeKart[brikke] == 1)){
				return true;
			}
			if(!jegErHvit && (brikkeKart[brikke] == 4 ||brikkeKart[brikke] == 3)){
				return  true;
			}
			return false;
		}
		
		public void resetLovligeHopp(){
			lovligeHoppFunnet=false;
			int[][]  lovligeHopp = new int[64][4];
			for(int i = 0; i<64;i++){
				for(int j = 0; j<4; j++){
					lovligeHopp[i][j] = 0;
				}
			}
			this.lovligeHopp = lovligeHopp;
		}
		
		public void resetBrikkerSomBlirHoppetOver(){
			int[][]  lovligeHopp = new int[64][4];
			for(int i = 0; i<64;i++){
				for(int j = 0; j<4; j++){
					lovligeHopp[i][j] = 0;
				}
			}
			this.brikkerSomBlirHoppetOver = lovligeHopp;
		}
		
		public void sjekkLovligeHopp() {
			lovligeHoppFunnet = false;
			for(int i = 0; i < brikkeKart.length; i++){
				if(erDetteMinBrikke(i) ){
					if(finnesDetLovligeHoppForEttFelt(i)){
						lovligeHoppFunnet = true;
						int[] h = lovligeHoppForEttFeltArray(i);
						int[] f = feltSomBlirHoppetOverArray(i);
						for(int j = 0; j<4 ; j++){
							lovligeHopp[i][j] = h[j];
							brikkerSomBlirHoppetOver[i][j] = f[j];
						}
					}
					
				}
			}
		}
				
		int[][][] sjekkLovligeHoppForEttFelt( int i) {
			int[][][] hoppArray = new int[2][64][4];
			if(erDetteMinBrikke(i) && finnesDetLovligeHoppForEttFelt(i)){
				int[] h = lovligeHoppForEttFeltArray(i);
				int[] f = feltSomBlirHoppetOverArray(i);
				for(int j = 0; j<4 ; j++){
					hoppArray[0][i][j] = h[j];
					hoppArray[1][i][j] = f[j];
				}
			}
			return hoppArray;
		}
		
		public int[] lovligeHoppForEttFeltArray(int i) {
			int[]a = {0,0,0,0};
				int brikkeType = brikkeKart[i];
				boolean brikkeKanGaOpp = brikkeKanGaOpp(brikkeType);
				boolean brikkeKanGaNed = brikkeKanGaNed(brikkeType);
				int teller = 0;
				if(hoppNW(i) && brikkeKanGaOpp && erDetteMotstanderenSinBrikke(punktNW(i)) && feltErTomt(hoppPunktNW(i))){
					a[teller] = hoppPunktNW(i);
					teller++;
				}
				if(hoppNE(i) && brikkeKanGaOpp && erDetteMotstanderenSinBrikke(punktNE(i)) && feltErTomt(hoppPunktNE(i))){
					a[teller] = hoppPunktNE(i);
					teller++;
				}
				if(hoppSW(i) && brikkeKanGaNed && erDetteMotstanderenSinBrikke(punktSW(i)) && feltErTomt(hoppPunktSW(i))){
					a[teller] = hoppPunktSW(i);
					teller++;
				}
				if(hoppSE(i) && brikkeKanGaNed && erDetteMotstanderenSinBrikke(punktSE(i)) && feltErTomt(hoppPunktSE(i))){
					a[teller] = hoppPunktSE(i);
					teller++;
				}
			return a;
		}
		
		public int[] feltSomBlirHoppetOverArray(int i) {
			int[]a ={0,0,0,0};
				int brikkeType = brikkeKart[i];
				boolean brikkeKanGaOpp = brikkeKanGaOpp(brikkeType);
				boolean brikkeKanGaNed = brikkeKanGaNed(brikkeType);
				int teller = 0;
				if(hoppNW(i) && brikkeKanGaOpp && erDetteMotstanderenSinBrikke(punktNW(i)) && feltErTomt(hoppPunktNW(i))){
					a[teller] = punktNW(i);
					teller++;
				}
				if(hoppNE(i) && brikkeKanGaOpp && erDetteMotstanderenSinBrikke(punktNE(i)) && feltErTomt(hoppPunktNE(i))){
					a[teller] = punktNE(i);
					teller++;
				}
				if(hoppSW(i) && brikkeKanGaNed && erDetteMotstanderenSinBrikke(punktSW(i)) && feltErTomt(hoppPunktSW(i))){
					a[teller] = punktSW(i);
					teller++;			}
				if(hoppSE(i) && brikkeKanGaNed && erDetteMotstanderenSinBrikke(punktSE(i)) && feltErTomt(hoppPunktSE(i))){
					a[teller] = punktSE(i);
				}
			return a;
		}
		public boolean finnesDetLovligeHoppForEttFelt(int position){
			boolean funnetLovligeHopp = false;
			int brikkeType = brikkeKart[position];
			boolean brikkeKanGaOpp = brikkeKanGaOpp(brikkeType);
			boolean brikkeKanGaNed = brikkeKanGaNed(brikkeType);			
			if(hoppNW(position) && brikkeKanGaOpp && erDetteMotstanderenSinBrikke(punktNW(position)) && feltErTomt(hoppPunktNW(position))){
				funnetLovligeHopp = true;
			}
			if(hoppNE(position) && brikkeKanGaOpp && erDetteMotstanderenSinBrikke(punktNE(position)) && feltErTomt(hoppPunktNE(position))){
				funnetLovligeHopp = true;
			}
			if(hoppSW(position) && brikkeKanGaNed && erDetteMotstanderenSinBrikke(punktSW(position)) && feltErTomt(hoppPunktSW(position))){
				funnetLovligeHopp = true;
			}
			if(hoppSE(position) && brikkeKanGaNed && erDetteMotstanderenSinBrikke(punktSE(position)) && feltErTomt(hoppPunktSE(position))){
				funnetLovligeHopp = true;
			}
			return funnetLovligeHopp;
		}

		public boolean erDetteMotstanderenSinBrikke(int brikke) {
			if(!jegErHvit && (brikkeKart[brikke] == 2 || brikkeKart[brikke] == 1)){
				return  true;
			}
			if(jegErHvit && (brikkeKart[brikke] == 4 || brikkeKart[brikke] == 3)){
				return  true;
			}
			return false;
		}
		
		public int hentPosition(int x, int y){
			return (y / 50)*8+(x / 50);
		}
		
		public int positionE(MouseEvent e) {
			return (e.getY() / 50)*8+(e.getX() / 50);
		}
		
		public void harJegTapt(){
			tellMineBrikker();
			int hoppFunnet = 0;
			if(sumMineBrikker > 0){
				for(int i = 0; i < brikkeKart.length; i++){
					if(erDetteMinBrikke(i) && (finnesDetLovligeHoppForEttFelt(i) || finnesDetLovligeTrekkForDenneBrikken(i))){
						hoppFunnet++;
					}
				}
				if(hoppFunnet==0){
					tapt=true;
				}
			}
			else{
				tapt = true;
			}
		}
		
		public void harJegVunnet(){
			tellMotspillersBrikker();
			int hoppFunnet = 0;
			if(sumMotspillerBrikker > 0){
				for(int i = 0; i < brikkeKart.length; i++){
					if(erDetteMotstanderenSinBrikke(i)){
						if(finnesDetLovligeHoppForEttFelt(i) || finnesDetLovligeTrekkForDenneBrikken(i)){
							hoppFunnet++;
						}	
					}
				}
				if(hoppFunnet == 0){
					vunnet=true;
				}
			}
			else{
				vunnet = true;
			}
		}
		
		public boolean nyttSpill(int[] oppdatertBrikkeKart) {
			int[] startPosBrikkeKart = lagNyttBrikkeKart();
			for(int i = 0; i < 64;i++){
				if(startPosBrikkeKart[i] != oppdatertBrikkeKart[i]){
					return false;
				}
			}
			lovligeHoppFunnet = false;
			lovligeTrekkFunnet = false;
			resetLovligeHopp();
			resetBrikkerSomBlirHoppetOver();
			return true;
		}
		public int[] lagNyttBrikkeKart(){
			int nyttBrikkeKart[] = new int[64];
			for(int i = 0; i < 64; i++){
					boolean partallRad = (i/8)%2==0;
					boolean partallRute = i%2==0;
					int brikketype = 0;
					if(i>=40 || i<24){
						if((!partallRad && partallRute) || (partallRad && !partallRute)){
							if(i>=40) brikketype = 1;
							if(i<24) brikketype = 3;
						}
					}
					nyttBrikkeKart[i] = brikketype;
				}
			return nyttBrikkeKart;
		}

		public void flytt(int valgtBrikke, int position) {
			int valgtBrikkeType = brikkeKart[valgtBrikke];
			brikkeKart[position]=valgtBrikkeType;
			brikkeKart[valgtBrikke]=0;
			nyttBrikkeKartSjekk();
		}
		
		public void nyttBrikkeKartSjekk() {
			lovligeTrekk.clear();
			resetLovligeHopp();
			resetBrikkerSomBlirHoppetOver();
			varSjekk();			
		}
		
		public boolean erDetteEttLovligHopp(int position) {
			for(int ii = 0; ii < lovligeHopp.length; ii++){
				for(int j = 0; j < 4 ;j++){
					if(lovligeHopp[ii][j] > 0){
						if(ii == position){
							return true;
						}
					}
				}
			}
			return false;
		}
		
		public boolean kanDenneBrikkenHoppeTilPosistion(int position, int valgtBrikke) {
			for(int ii = 0; ii < lovligeHopp.length; ii++){
				for(int j = 0; j < 4 ;j++){
					if(lovligeHopp[ii][j] > 0){
						if(lovligeHopp[ii][j] == position && valgtBrikke != 99 && valgtBrikke == ii){
							return true;
						}
					}
				}
			}
			return false;
		}
		public void hopp(int position, int valgtBrikke) {
			int valgtBrikkeType = brikkeKart[valgtBrikke];
			brikkeKart[position]=valgtBrikkeType; // feltet brikken hopper til
			brikkeKart[valgtBrikke]=0; // Feltet brikken hoppet fra
			brikkeKart[((position - valgtBrikke)/2)+valgtBrikke] = 0; // Brikken du hoppet over
			sjekkBrikkeStatus();
			varSjekk();
			
		}
		public int[] giOpp() {
			nyttBrikkekart();
			tapt = true;
			System.out.println("Jeg gir opp");
			brikkeKart[0] = 10;
			return brikkeKart;
		}
		public void sjekkSpm() {
			System.out.println("Sjekker spm: " + brikkeKart[0]);
			vunnet = false;
			tapt = false;
			motspillerVilStartePaNytt = false;
			if(brikkeKart[0] == 10){ // motspiller gir opp
				vunnet = true;
				System.out.println("Motspiller gir opp");
			}
			if(jegErHvit && brikkeKart[0] == 20 || !jegErHvit && brikkeKart[0] == 21){
				motspillerVilStartePaNytt = true;
				System.out.println("Motspiller vil restarte");
			}
			if(brikkeKart[0] == 22){ // VIL IKKE RESTARTE _ NEITAKK
				resetStartPaNytt();
				System.out.println("Motspiller vil ikke restarte");
			}
			tomSpm();
		}
				
		public void tomSpm() {
			brikkeKart[0] = 0;
			
		}
		public int[] startPaNytt() {
			int jegVilRestarteNr = 20;
			if(jegErHvit){
				jegVilRestarteNr = 21;
			}
			System.out.println("Jeg vil restarte");
			brikkeKart[0] = jegVilRestarteNr;
			jegVilStartePaNytt = true;
			System.out.println(brikkeKart[0]);
			return brikkeKart;
		}
		
		public void jegVilIkkeRestarte() {
			brikkeKart[0] = 22;
		}
		
		public void lagreMotstanderSinBrikkePos() {
			if(!motstanderSinBrikkePos.isEmpty()){
				motstanderSinBrikkePos.clear();
			}
			for(int i = 1; i < brikkeKart.length; i++){
				if(erDetteMotstanderenSinBrikke(i)){
					motstanderSinBrikkePos.add(i);
				}
			}
		}
		
		public void sjekkMotstanderSinBrikkePos(){
			if(!motstanderSinBrikkePos.isEmpty()){
				ArrayList<Integer> tempArray = new ArrayList<Integer>();
				for(int g = 0; g < brikkeKart.length; g++){
					if(erDetteMotstanderenSinBrikke(g)){
						tempArray.add(g);
					}
				}
				boolean b = false;
				boolean a = false;
				if(motstanderSinBrikkePos.size() == tempArray.size()){
					for(int i = 0; i < motstanderSinBrikkePos.size(); i++){
						if(!tempArray.contains(motstanderSinBrikkePos.get(i))){
							motstanderSisteFraTrekk = motstanderSinBrikkePos.get(i);
							a = true;
						}
						if(!motstanderSinBrikkePos.contains(tempArray.get(i))){
							motstanderSisteTilTrekk = tempArray.get(i);
							b = true;
						}
					}
				}
				if(a && b){
					funnetMotstanderSittSisteTrekk = true;
					motstanderSinBrikkePos.clear();
				}
			}
		}		
}

		